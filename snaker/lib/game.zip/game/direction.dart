enum Direction { up, down, left, right }
